This is an example update package.
The main executable does absolutely nothing and is simply a placeholder.